PicoPod for Windows x64

Extract the WHOLE PicoPod folder and double-click PicoPod.exe.
Python, Tcl/Tk, dependencies and the USB helper are included.
Codex, a Python installation, and a copied .venv are NOT required.
Keep PicoPod.exe and the _internal folder together.
Use a writable location such as Documents (not Program Files).

Songs/playlists save in userdata beside PicoPod.exe. Original MP3s must be
available on this computer; audio files and another user's library are not
included in the downloadable ZIP. Add your local MP3s in the app.
Close older copies of PicoPod and serial apps before USB uploads.
The Windows card helper may request admin permission after card confirmation.

Offline preview is available in the GUI, or PicoPod.exe --preview.
